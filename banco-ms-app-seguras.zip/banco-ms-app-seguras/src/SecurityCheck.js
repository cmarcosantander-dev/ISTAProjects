import React from 'react';

class SecurityCheck extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedIcon: null,
      answer: ''
    };
  }

  handleIconClick = (icon) => {
    this.setState({ selectedIcon: icon });
  }

  handleSubmit = (event) => {
    event.preventDefault();
    const { answer, selectedIcon } = this.state;
    const { user, onAccessGranted } = this.props;

    if (answer === user.securityAnswer && selectedIcon === user.securityIcon) {
      onAccessGranted();
    } else {
      alert('Respuesta o icono incorrecto');
    }
  }

  handleChange = (event) => {
    this.setState({ answer: event.target.value });
  }

  render() {
    const { user } = this.props;
    const { selectedIcon } = this.state;
    const icons = [
      'pelota.JPG', 'ancla.PNG', 'bicicleta.PNG', 'billete.PNG', 'calculadora.PNG',
      'corazon.PNG', 'impresora.PNG', 'metro.PNG', 'microfono.PNG', 'mundo.PNG',
      'palmera.PNG', 'paloma.PNG', 'satelite.PNG', 'taco.PNG', 'telefono.PNG', 'televisor.PNG'
    ];

    return (
      <div className="security-check-container">
        <h2>Pregunta de seguridad</h2>
        <form onSubmit={this.handleSubmit} className="security-check-form">
          <label>
            {user.securityQuestion}
            <input type="text" name="answer" onChange={this.handleChange} />
          </label>
          <div className="icons">
            {icons.map((icon) => (
              <img
                key={icon}
                src={`/${icon}`}
                alt={icon}
                className={`icon ${selectedIcon === icon ? 'selected' : ''}`}
                onClick={() => this.handleIconClick(icon)}
              />
            ))}
          </div>
          <button type="submit">Ingresar</button>
        </form>
      </div>
    );
  }
}

export default SecurityCheck;
